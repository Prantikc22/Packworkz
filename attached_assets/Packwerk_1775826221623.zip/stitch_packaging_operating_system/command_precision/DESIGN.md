```markdown
# Design System Strategy: High-Performance Editorial

## 1. Overview & Creative North Star: "The Tactical Architect"

This design system is built to move beyond the generic "SaaS dashboard" aesthetic. Our North Star is **The Tactical Architect**: a visual language that feels as precise as a blueprint but as authoritative as an editorial masthead. 

We reject the "boxed-in" nature of traditional B2B software. Instead, we embrace **Functional Brutalism**—using high-contrast typography scales, intentional asymmetry, and "The Layering Principle" to create a sense of depth and command. Every pixel must feel like a deliberate choice. We don't just display data; we orchestrate it.

---

## 2. Color & Atmosphere

Our palette is anchored by **Command Navy** (#0D1B2A), conveying deep-seated authority. We use **Electric Blue** (#1B6CA8) for technical precision and **Amber** (#E8A838) for high-impact actions.

### The "No-Line" Rule
Traditional 1px borders are often a crutch for poor hierarchy. In this system, **1px solid borders are prohibited for sectioning.** Boundaries must be defined through:
- **Background Shifts:** Using `surface-container-low` against a `surface` background.
- **Tonal Transitions:** Defining edges through subtle shifts in saturation rather than lines.

### Surface Hierarchy & Nesting
Think of the UI as a physical stack of premium materials.
1. **Base:** `surface` (#F8F9FC) — The foundation.
2. **Level 1:** `surface-container-low` (#F2F3F6) — For large content blocks.
3. **Level 2:** `surface-container-highest` (#E1E2E5) — For active interactive elements or "pop-out" utility panels.

### The "Glass & Gradient" Rule
To inject "soul" into the B2B experience, utilize **Glassmorphism** for floating menus and modals. Use a 15% opacity `surface` color with a `20px` backdrop-blur. 
*   **Signature Texture:** For primary CTAs and Hero sections, use a subtle linear gradient: `primary` (#0D1B2A) to `primary_container` (#0F1C2C) at a 135-degree angle. This adds a "machined" metallic depth that flat hex codes cannot replicate.

---

## 3. Typography: Editorial Authority

We use typography as a layout element, not just for legibility.

*   **Display (Clash Display / Syne):** These are our "Impact" fonts. Use `display-lg` (3.5rem) with tight letter-spacing (-0.02em) to create an authoritative, editorial feel.
*   **Headlines (Plus Jakarta Sans Bold):** These act as the "Structural" anchors. They bridge the gap between high-fashion display and functional body text.
*   **Stats/IDs (JetBrains Mono):** Anything technical—tracking IDs, timestamps, or raw metrics—must use JetBrains Mono. This signals "Data Integrity" and "Developer-Grade" precision.
*   **Body (Plus Jakarta Sans Regular):** Set at `body-lg` (1rem) with a generous `1.6` line-height to ensure the interface breathes.

---

## 4. Elevation & Depth: Tonal Layering

We avoid the "shadow-heavy" look of 2010-era design. Depth is achieved through light and layering.

*   **The Layering Principle:** Place a `surface_container_lowest` (#FFFFFF) card on a `surface_container_low` (#F2F3F6) section. The contrast creates a natural, soft lift without a single drop shadow.
*   **Ambient Shadows:** When an element *must* float (e.g., a dropdown), use a shadow with a 32px blur at 4% opacity. The shadow color must be tinted with our `on_surface` color (`#191C1E`)—never pure black.
*   **The "Ghost Border" Fallback:** If a container needs an edge for accessibility, use the `outline_variant` (#C4C6CC) at **15% opacity**. It should be felt, not seen.
*   **Purposeful Motion:** Use staggered fade-ups (300ms duration, 20ms stagger) for list items. This reinforces the "High-Performance" aspect of the brand.

---

## 5. Components

### Buttons (Tactical Precision)
*   **Primary:** Gradient of `primary` to `primary_container`. `0.25rem` (4px) corner radius. No border.
*   **Secondary:** `surface_container_highest` background with `on_primary_fixed_variant` text.
*   **CTA (Amber):** Use `tertiary_fixed` (#FFDDAF) background with `on_tertiary_fixed` text for extreme contrast.

### Cards & Lists
*   **Rule:** **No Divider Lines.**
*   Separate list items using `8px` of vertical white space or a subtle hover state shift to `surface_container_high`. 
*   **Contextual Stat Cards:** Use JetBrains Mono for the value and Plus Jakarta Sans (Label-SM) for the description. Ensure the value is at least 200% larger than the label.

### Input Fields
*   **State:** Default state uses a `surface_container_highest` background. 
*   **Focus:** Transition to a 1px `secondary` (#02629E) "Ghost Border" (20% opacity) and a subtle 4px outer glow of the same color.

### Custom Component: The "Command Bar"
A floating, semi-transparent (`surface` @ 80% opacity + blur) bar at the bottom of the screen for quick tactical actions. This reinforces the "PackOps" persona of being always ready and authoritative.

---

## 6. Do’s and Don’ts

### Do:
*   **Use Asymmetry:** Align text to the left but place supporting stats or IDs in the far top-right of a container to create a "Technical Blueprint" look.
*   **Embrace Whitespace:** If you think there’s enough space, add 16px more.
*   **Color as Information:** Use `Amber` strictly for "Attention Required" and `Electric Blue` for "Interactive/Actionable."

### Don’t:
*   **Don't use Rounded Corners > 12px:** We are "Precise" and "Authoritative." Stay within the `0.25rem` to `0.75rem` range. Never use "pill" shapes for buttons unless it's a tag/chip.
*   **Don't use pure Black (#000):** It kills the depth of the Command Navy. Use `primary_container` (#0F1C2C) for the darkest values.
*   **Don't use Centered Text:** Editorial design lives on the margins. Stick to strong left alignments for headings and body.

---

**Director’s Note:** This system is about the tension between the "Heavy" (Navy/Bold Type) and the "Light" (Whitespace/Glassmorphism). Maintain that balance, and the UI will feel like a world-class tool.```